import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 
import mplleaflet as mpll
import seaborn as sns

df1 = pd.read_csv('listings_summary.csv') 
df3 = pd.read_csv('listings_detailed.csv')

def interactive_map():
    rids = np.arange(df1.shape[0])
    np.random.shuffle(rids)
    f, ax = plt.subplots()
    df1.iloc[rids[:2000], :].plot(kind='scatter', x='longitude', y='latitude',s=15, linewidth=0, ax=ax)
    mpll.display(fig=f,) 
    mpll.show(fig=f)

df3['price'] = df3.price.apply(lambda x: x.replace('$','')).apply(lambda x: x.replace(',','')).apply(lambda x: x.replace('.00',''))
df3.price = df3.price.astype(np.int64)

def neighborhood_bedroom_for_price():
    plt.figure(figsize=(10,10))
    cmap = sns.cubehelix_palette(10, start=0, rot=1, as_cmap=True) 
    sns.heatmap(df3.groupby(['neighbourhood', 'bedrooms']).price.median().unstack(),annot=True, fmt=".0f", cmap=cmap)
    plt.ion()
    plt.show()
