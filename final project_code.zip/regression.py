import numpy as np
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv('listings_detailed.csv') 

columns_to_keep = ['bedrooms','neighbourhood','price','bathrooms']
data = data[columns_to_keep]

data['price'] = data.price.apply(lambda x: x.replace('$','')).apply(lambda x: x.replace(',','')).apply(lambda x: x.replace('.00',''))
data.price = data.price.astype(np.int64)
data.neighbourhood = data.neighbourhood.astype(str)

def neighbourhood_regression(neighbourhood,bedrooms,bathrooms):
    condition = (data['neighbourhood'] == neighbourhood)
    df = data.loc[condition]
    df1 = df.dropna()
    d = df1.drop(columns=['neighbourhood'])
    d1 = d.copy()
    d = d.drop(columns='price')
    y = d1['price'] 
    X = sm.add_constant(d)
    model = sm.OLS(y, X).fit()
    return int(bedrooms*model.params['bedrooms'])+int(bathrooms+model.params['bathrooms'])+int(model.params['const'])