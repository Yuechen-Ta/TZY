import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import datetime as dt
from datetime import datetime

data = pd.read_csv('calendar_detailed.csv.gz')

data = data.drop(columns=['price', 'minimum_nights', 'maximum_nights', 'available'])
data['adjusted_price'] = data.adjusted_price.apply(lambda x: x.replace('$','')).apply(lambda x: x.replace(',',''))
data = data.dropna()

data['date']=pd.to_datetime(data['date'])
data['weekday'] = pd.Series(data.date).dt.dayofweek
data.to_csv(r'Calendar_cleaned.csv',index = False)
df = pd.read_csv('Calendar_cleaned.csv')

def individual_date(listing_id,date_start,date_end):
    listing = df.loc[df['listing_id'] == listing_id]
    date = listing.loc[(listing['date'] > date_start) & (listing['date'] <= date_end)]
    return date

def lowest_individual_date(listing_id,date_start,date_end):
    listing = df.loc[df['listing_id'] == listing_id]
    date = listing.loc[(listing['date'] > date_start) & (listing['date'] <= date_end)]
    return date.min()

def price_change():
    date=[]
    median_price=[]
    for i in data['date'].unique():
        date.append(i)
        median_price.append(data[data['date'] == i]['adjusted_price'].median())
    plt.figure(figsize=(10,10))
    plt.plot(date, median_price, color='red')
    plt.ylabel('Price($)')
    plt.xlabel('Day of 2020-2021')
    plt.title('Median Price of AirBnB Listings')
    plt.ion()
    plt.show()

