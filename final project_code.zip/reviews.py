import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
sid = SentimentIntensityAnalyzer()
from scipy import stats

df = pd.read_csv('reviews_summary.csv')
df1 = pd.read_csv('reviews_detailed.csv')
df2 = pd.read_csv('listings_detailed.csv')

columns_to_keep1 = ['listing_id','comments'] 
df1 = df1[columns_to_keep1] 

columns_to_keep2 = ['id','neighbourhood','bedrooms','bathrooms','reviews_per_month'] 
df2 = df2[columns_to_keep2]

def review_score(listing_id):
    listing = df1.loc[df1['listing_id'] == listing_id]
    review = [i for i in listing['comments']]
    pscores = [sid.polarity_scores(comment)['compound'] for comment in review]
    listing_score = sum(pscores)/len(listing)
    sample_review = df1.sample(frac=1)[:10000]
    total = [str(i) for i in sample_review['comments']]
    pscores = [sid.polarity_scores(comments)['compound'] for comments in total]
    return stats.percentileofscore(pscores, listing_score)

def recommendation(neighbourhood,bedrooms,bathrooms):
    try:
        condition = ((df2['neighbourhood'] == neighbourhood)&
                     (df2['bedrooms'] == bedrooms)&
                     (df2['bathrooms'] == bathrooms))
        new = df2.loc[condition]
        list1 = new['id'].values.tolist()
        list2 = df1.loc[df1['listing_id'].isin(list1)]
        review = [i for i in list2['comments']]
        pscores = [sid.polarity_scores(str(comment))['compound'] for comment in review]
        list2['score'] = pscores
        group = list2.groupby(['listing_id']).mean()
        pscore = group.values.tolist()
        pscore = [item for sublist in pscore for item in sublist]
        freq= []
        for i in list1:
            freq.append(df2['reviews_per_month'].loc[df2['id']==i].item())
        freq = [float(i/5) for i in freq if str(i) != 'nan']
        combine = [] 
        for i in range(0, len(pscore)): 
            combine.append(freq[i] + pscore[i]) 
        df = pd.DataFrame(list(zip(list1, combine)),columns =['id', 'combine'])
        df = df.sort_values(by=['combine'], ascending=False)
        return df['id'].iloc[0]
    except IndexError:
        print('Oops, no matching Airbnb can be found')