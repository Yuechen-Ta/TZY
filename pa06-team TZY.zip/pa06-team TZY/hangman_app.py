"""
   hangman_app.py is an app for playing hangman in the terminal
   it is also used as a module in the hangman_webapp flask app
"""
import random
import requests

def generate_random_word():
    return random.choice(requests.get('https://raw.githubusercontent.com/dwyl/english-words/master/words_alpha.txt')
                         .content.decode().splitlines())
def print_word(current_word, guessed_letter,word):
    letters = [i for i in word]
    current_letters = [i for i in current_word]
    global count

    if guessed_letter in letters and guessed_letter not in current_letters:
        print('Congrats')
        for n, i in enumerate(letters): 
            if i == guessed_letter:
                current_letters[n] = guessed_letter
        current_word = "".join(current_letters)
        print(current_word)
        
    else:
        count-=1
        print('Sorry')
        print(current_word)

    return current_word

def play_hangman():
    
    while True:
        global count
        word = generate_random_word()
        count = 6
        current_word = "".join(len(word)*['_'])
        print(current_word)
        print('There are',len(word),'letters in this word')
        print(word)#delete
        while count>0 and current_word != word:     
            guessed_letter = input('a letter: ')
            current_word = print_word(current_word, guessed_letter,word)
            print(count)#delete

        if current_word == word:
            print('success')
        else:
            print('you lose')
            
        intention = input("Ture/False")
        if intention == 'False':
            break
            

if __name__ == '__main__':
    play_hangman()
